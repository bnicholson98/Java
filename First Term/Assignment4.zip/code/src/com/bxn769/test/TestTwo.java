package com.bxn769.test;
import com.bxn769.item.*;
import com.bxn769.enemy.*;

public class TestTwo{
	public static void main(String args[]) {
		System.out.println("Weapon test.");
		Weapon gun = new Weapon("Gun");
		System.out.println(gun.getType());
		System.out.println();
		
		System.out.println("BaseEnemy test.");
		BaseEnemy basic = new BaseEnemy("Basic Enemy");
		basic.setHealth(-10.0f);
		System.out.println(Float.toString(basic.getHealth()));
		System.out.println(Float.toString(basic.getMAX_HEALTH()));
		System.out.println();
		
		System.out.println("IntelligentEnemy test.");
		IntelligentEnemy intelligent = new IntelligentEnemy("Intelligent Enemy");
		intelligent.setHealth(-100.0f);
		System.out.println(intelligent.checkIfAlive());
		System.out.println(Float.toString(intelligent.getIntelligence()));
		intelligent.setIntelligence(50.0f);
		System.out.println(Float.toString(intelligent.getIntelligence()));
		System.out.println();
		
		System.out.println("Zombie test.");
		Zombie zombie = new Zombie("Basic Zombie");
		zombie.decompose();
		System.out.println(Float.toString(zombie.getHealth()));
		zombie.changeAngerLevel(25f);
		System.out.println(Float.toString(zombie.getAngerLevel()));
		System.out.println();
		
		System.out.println("LegendaryZombie test.");
		LegendaryZombie legend = new LegendaryZombie("Legend Zombie");
		legend.addWeapon(gun);
		System.out.println(Integer.toString(legend.getWeaponListSize()));
		legend.mutate();
		System.out.println(legend.toString());
		System.out.println();
		
		System.out.println("Ghoul test.");
		Ghoul ghoul = new Ghoul("Basic Ghoul");
		ghoul.increasePutridity();
		System.out.println(Float.toString(ghoul.getPutridityLevel()));
		System.out.println();
		
		System.out.println("RadioactiveGhoul test.");
		RadioactiveGhoul radioactive = new RadioactiveGhoul("Radioactive Ghoul");
		radioactive.changeRadioactivity(-60f);
		System.out.println(Float.toString(radioactive.getRadioactivity()));
		radioactive.setIntelligence(10f);
		System.out.println(Float.toString(radioactive.getIntelligence()));
		System.out.println();
		
		System.out.println("Mutant test.");
		Mutant mutant = new Mutant("Basic Mutant");
		System.out.println(Float.toString(mutant.getIntelligence()));
		mutant.setHealth(20f);
		System.out.println(Float.toString(mutant.getHealth()));
		System.out.println(Float.toString(mutant.getIntelligence()));
		for (int i = 0;i < 5;i++){
			mutant.addWeapon(gun);
			System.out.println(Integer.toString(mutant.getWeaponListSize()));
		}
	}
}
				
			
			
			
			
			
			
			
			