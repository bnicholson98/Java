package com.bxn769.test;
import com.bxn769.enemy.*;
import com.bxn769.item.*;

public class TestOne{
	public static void main(String args[]) {
		BaseEnemy enemy = new BaseEnemy("Enemy");
		System.out.println(enemy.toString());
		System.out.println();
		
		IntelligentEnemy intelligentEnemy = new IntelligentEnemy("Intelligent");
		System.out.println(intelligentEnemy.toString());
		System.out.println();
		
		Zombie zombie = new Zombie("Zombie");
		System.out.println(zombie.toString());
		System.out.println();
		
		LegendaryZombie legend = new LegendaryZombie("Legend");
		System.out.println(legend.toString());
		System.out.println();
		
		Ghoul ghoul = new Ghoul("Ghoul");
		System.out.println(ghoul.toString());
		System.out.println();
		
		Ghoul radioactive = new RadioactiveGhoul("Radioactive");
		System.out.println(radioactive.toString());
		System.out.println();
		
		Mutant mutant = new Mutant("Mutant");
		System.out.println(mutant.toString());
	}
}
	