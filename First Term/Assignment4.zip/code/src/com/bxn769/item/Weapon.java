/** Calls package being used for the class */
package com.bxn769.item;

/** The Weapon class */
public class Weapon{
	/** The type of weapon */
	private String type;
	
	/**  
	Constructor.
	@param type The type of weapon.
	*/
	public Weapon(String type){
		this.type = type;
	}
	
	/**
	Get the type of weapon.
	@return the type of weapon.
	*/
	public String getType(){
		return type;
	}
}