/** Package being used */
package com.bxn769.enemy;

/**
The RadioactiveGhoul class
*/
public class RadioactiveGhoul extends Ghoul{
	protected float radioactivity = 50.0f;
	protected float MAX_RADIOACTIVITY = 100.0f;
	
	/**
	Constructor.
	@param name The name of the enemy.
	name is called through the base class.
	*/
	public RadioactiveGhoul(String name){
		super(name);
	}

	/**
	Getter for raidoactivity.
	@return radioactivity.
	*/
	public float getRadioactivity(){
		return this.radioactivity;
	}
	
	/**
	Method to increase or decrease radioactivity, checks if change in radioactivity is
	positive or negative as well as limiting the radioactivity between 0 and MAX_RADIOACTIVITY.
	@param radioactivityChange a pos or neg float to add or subtract from radioactivity
	*/
	public void changeRadioactivity(float radioactivityChange){
		if (radioactivityChange > 0){
			if (this.radioactivity < this.MAX_RADIOACTIVITY){
				this.radioactivity += radioactivityChange;
				if (this.radioactivity > this.MAX_RADIOACTIVITY){
					this.radioactivity = this.MAX_RADIOACTIVITY;
				}
			}
		}else{

			if (this.radioactivity > 0){
				this.radioactivity += radioactivityChange; //Since it will add a negative float
				if (this.radioactivity < 0){
					this.radioactivity = 0;
				}
			}
		}
	}
		
	/**
	Creates a string of the class attributes.
	@return The string of the class attributes.
	*/
	@Override
	public String toString(){
		String s = "";
		
		s += "Name = ";
		s += getName();
		s += "\nHealth = ";
		s += Float.toString(getHealth());
		s += "\nIntelligence = ";
		s += Float.toString(getIntelligence());
		s += "\nPutridity = ";
		s += Float.toString(getPutridityLevel());
		s += "\nRadioactivity level = ";
		s += Float.toString(getRadioactivity());

		return s;
	}
	
}