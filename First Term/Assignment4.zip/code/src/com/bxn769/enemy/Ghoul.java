/** Package being used */
package com.bxn769.enemy;

/**
The Ghoul class
*/
public class Ghoul extends IntelligentEnemy{
	/** putridity level of the ghoul */
	protected float putridityLevel = 0.0f;
	/** maximum putridity a ghoul can have */
	protected float MAX_PUTRIDITY = 1.0f;
	/** maximum health a ghoul can have */
	protected float MAX_HEALTH = 150.0f;
	
	
	/**
	Constructor.
	@param name The name of the enemy.
	name is called through the base class.
	*/
	public Ghoul(String name){
		super(name);
	}
	
	/**
	Getter for putridityLevel.
	@return putridityLevel.
	*/
	public float getPutridityLevel(){
		return this.putridityLevel;
	}
	
	/**
	method to increase the putridity level by 0.1 and then set
	health to max if putridity is max
	*/
	public void increasePutridity(){
		if (putridityLevel < MAX_PUTRIDITY){
			putridityLevel += 0.1;
			if (putridityLevel == MAX_PUTRIDITY){
				this.health = this.MAX_HEALTH;
			}
		}
	}
	
	
	/**
	Creates a string of the class attributes.
	@return The string of the class attributes.
	*/
	@Override
	public String toString(){
		String s = "";
		
		s += "Name = ";
		s += getName();
		s += "\nHealth = ";
		s += Float.toString(getHealth());
		s += "\nIntelligence = ";
		s += Float.toString(getIntelligence());
		s += "\nPutridity = ";
		s += Float.toString(getPutridityLevel());

		return s;
	}
	
	
	
	
	
	
	
	
}
	