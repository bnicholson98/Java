/** Call package being used for the class */
package com.bxn769.enemy;
/** Import of ArrayList class */
import java.util.ArrayList;
import com.bxn769.item.*;

/**
The BaseEnemy class
*/
public class BaseEnemy{
	/** The name of the enemy. */
	protected String name;
	/** The maximum health of the enemy set to 100 */
	protected float MAX_HEALTH = 100.0f;
	/** The health of the enemy initially set to the maximum health */
	protected float health = MAX_HEALTH;
	/** Boolean to store if the enemy is alive or not */
	protected boolean isAlive = true;
	/** ArrayList for weapon objects */
	protected ArrayList<Weapon> weaponList = new ArrayList<Weapon>();
	/** Int value for the max number of weapons an enemy can have,
	this will be the max size of the list */
	protected int MAX_NUM_OF_WEAPONS;
	
	/**
	Constructor.
	@param name The name of the enemy.
	*/
	public BaseEnemy(String name){
		this.name = name;
	}
	
	/**
	Sets the health of the enemy when changing.
	Uses checkIfAlive to only change the health if the enemy is alive.
	@param healthChange the amount by which the health will
	increase or decrease.
	*/
	public void setHealth(float healthChange){
		if (checkIfAlive()){
			this.health += healthChange;
			if (this.health <= 0){
				this.isAlive = false;
				this.health = 0;
			}
			if (this.health > MAX_HEALTH){
				this.health = this.MAX_HEALTH;
			}
		}
	}
	
	/**
	Gets the name of the enemy.
	@return The name of the enemy*/
	public String getName(){
		return this.name;
	}
	
	/**
	Gets the maximun health of the enemy.
	@return The max health of the enemy.
	*/
	public float getMAX_HEALTH(){
		return this.MAX_HEALTH;
	}
	
	/**
	Gets the health of the enemy.
	@return The health of the enemy/
	*/
	public float getHealth(){
		return this.health;
	}
	
	/**
	Checks the state of the isAlive boolean.
	@return A boolean representing if the enemy
	is alive or not.
	*/
	public boolean checkIfAlive(){
		if (this.health > 0){
			return true;
		}else{
			this.health = 0;
			return false;
		}
	}
	
	/**
	Creates a string of the class attributes.
	@return The string of the class attributes.
	*/
	public String toString(){
		String s = "";
		
		s += "Name = ";
		s += getName();
		s += "\nHealth = ";
		s += Float.toString(getHealth());

		return s;
	}
}
		
		
		
		
		
		
		
		
		