/** Package being used */
package com.bxn769.enemy;
import com.bxn769.item.*;
import java.util.ArrayList;
;
/**
Zombie class
*/
public class Zombie extends BaseEnemy{
	/** Decomposition rate of the zombie */
	protected float DECOMPOSITION_RATE = 0.5f;
	/** Anger level of the zombie */
	protected float angerLevel = 0.0f;
	/** Maximum anger a zombie can have */
	protected float MAX_ANGER = 50.0f; 
	/** Int value for the max number of weapons an enemy can have,
	this will be the max size of the list,
	this is taken from the base class	*/
	protected int MAX_NUM_OF_WEAPONS = 2;
	
	/**
	Constructor.
	@param name The name of the enemy.
	name is called through the base class.
	*/
	public Zombie(String name){
		super(name);
	}
	
	/**
	Getter for the size of the weapon list.
	@return the size of the weaponList ArrayList using .size() method.
	*/
	public Integer getWeaponListSize(){
		return weaponList.size();
	}
		
	/**
	Method to reduce the zombie's health by the decomp rate
	and check if it is still alive
	*/
	public void decompose(){
		if (this.isAlive){
			this.health -= this.DECOMPOSITION_RATE;
			if (!(checkIfAlive())){
				this.isAlive = false;
			}
		}
	}
	
	
	/**
	Method to increase or decrease anger levels, checks if angerLevel is
	positive or negative as well as limiting the angerLevel between 0 and MAX_ANGER.
	@param angerChange a pos or neg float to add or subtract from angerLevel
	*/
	public void changeAngerLevel(float angerChange){
		if (angerChange > 0){
			if (this.angerLevel < this.MAX_ANGER){
				this.angerLevel += angerChange;
				if (this.angerLevel > this.MAX_ANGER){
					this.angerLevel = this.MAX_ANGER;
				}
			}
		}else{
			if (this.angerLevel > 0){
				this.angerLevel += angerChange; //Since it will add a negative float
				if (this.angerLevel < 0){
					this.angerLevel = 0;
				}
			}
		}
	}
	
	/**
	Gets the angerLevel of the zombie.
	@return angerLevel
	*/
	public float getAngerLevel(){
		return this.angerLevel;
	}
	
	/**
	Method to add a weapon to the weaponList if there are spaces
	within the list.
	@param weapon The weapon that is attempting to be added to the list.
	*/
	public void addWeapon(Weapon weapon){
		if (weaponList.size() <= MAX_NUM_OF_WEAPONS){
			weaponList.add(weapon);
		}
	}
	
	/**
	Creates a string of the class attributes.
	@return The string of the class attributes.
	*/
	@Override
	public String toString(){
		String s = "";
		
		s += "Name = ";
		s += getName();
		s += "\nHealth = ";
		s += Float.toString(getHealth());
		s += "\nAnger level = ";
		s += Float.toString(getAngerLevel());
		s += "\nNumber of weapons = ";
		s += Integer.toString(weaponList.size());

		return s;
	}
}
	
	
	
	
	