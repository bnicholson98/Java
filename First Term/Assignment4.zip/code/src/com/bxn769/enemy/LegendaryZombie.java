/** Package being used */
package com.bxn769.enemy;
import com.bxn769.item.*;

/**
The LegendaryZombie class
*/
public class LegendaryZombie extends Zombie{
	/** Decomposition rate of the legendary zombie */
	protected float DECOMPOSITION_RATE = 0.05f;
	/** Maximum health larger, set to 500.0 */
	protected float MAX_HEALTH = 500.0f;
	/** Maximum anger a legendary zombie can have */
	protected float MAX_ANGER = 100.0f; 
	/** Initial anger a legendary zombie has */
	protected float angerLevel = 50.0f;

	/**
	Constructor.
	@param name The name of the enemy.
	name is called through the base class.
	*/
	public LegendaryZombie(String name){
		super(name);
	}
	
	public void mutate(){
		this.health = this.MAX_HEALTH;
		this.angerLevel = this.MAX_ANGER;
	}
	
	//no need to override toString() method as it is the same
	//as it's base class
}


