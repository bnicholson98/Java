/** Package being used */
package com.bxn769.enemy;
import com.bxn769.item.*;
import java.util.ArrayList;
/**
The Mutant class
*/
public class Mutant extends IntelligentEnemy{
	/** Int value for the max number of weapons an enemy can have,
	this will be the max size of the list,
	this is taken from the base class	*/
	protected int MAX_NUM_OF_WEAPONS = 4;
	
	/**
	Constructor.
	@param name The name of the enemy.
	name is called through the base class.
	*/
	public Mutant(String name){
		super(name);
	}
	
	/**
	Getter for the size of the weapon list.
	@return the size of the weaponList ArrayList using .size() method.
	*/
	public Integer getWeaponListSize(){
		return weaponList.size();
	}
		
	/**
	Override from parent class.
	Sets the health of the enemy when changing.
	Uses checkIfAlive to only change the health if the enemy is alive.
	Also increases or decreases the intelligence by 2.0 where applicable.
	@param healthChange the amount by which the health will
	increase or decrease.
	*/
	@Override
	public void setHealth(float healthChange){
		if (checkIfAlive()){
			if (healthChange > 0){
				this.intelligence += 2;
				this.health += healthChange;
				if (this.health > MAX_HEALTH){
					this.health = this.MAX_HEALTH;
				}
			}else if(healthChange < 0){
				this.intelligence -= 2;
				if (this.health <= 0){
					this.isAlive = false;
				}
			}		
		}
	}
	
	/**
	Method to add a weapon to the weaponList if there are spaces
	within the list.
	@param weapon The weapon that is attempting to be added to the list.
	*/
	public void addWeapon(Weapon weapon){
		if (weaponList.size() < MAX_NUM_OF_WEAPONS){
			weaponList.add(weapon);
		}
	}
	
	/**
	Creates a string of the class attributes.
	@return The string of the class attributes.
	*/
	@Override
	public String toString(){
		String s = "";
		
		s += "Name = ";
		s += getName();
		s += "\nHealth = ";
		s += Float.toString(getHealth());
		s += "\nIntelligence = ";
		s += Float.toString(getIntelligence());
		s += "\nNumber of weapons = ";
		s += Integer.toString(weaponList.size());

		return s;
	}
}