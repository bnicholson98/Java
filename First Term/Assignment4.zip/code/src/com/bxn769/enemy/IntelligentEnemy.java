/** Package being used */
package com.bxn769.enemy;

/**
The IntelligentEnemy class
*/
public class IntelligentEnemy extends BaseEnemy{
	/** Intelligence of the enemy */
	protected float intelligence = 25.0f;
	/** Maximum intelligence an enemy can have */
	protected final float MAX_INTELLIGENCE = 50.0f;
	
	/**
	Constructor.
	@param name The name of the enemy.
	name is called through the base class.
	*/
	public IntelligentEnemy(String name){
		super(name);
	}
	
	/**
	Method to increase or decrease intelligence, checks if intelligenceChange is
	positive or negative as well as limiting the intelligence between 0 and MAX_INTELLIGENCE.
	@param intelligenceChange A positive or negative float to indicate the change in intelligence.
	*/
	public void setIntelligence(float intelligenceChange){
		if (intelligenceChange > 0){
			if (this.intelligence < this.MAX_INTELLIGENCE){
				this.intelligence += intelligenceChange;
				if (this.intelligence > this.MAX_INTELLIGENCE){
					this.intelligence = this.MAX_INTELLIGENCE;
				}
			}
		}else{
			if (this.intelligence > 0){
				this.intelligence += intelligenceChange; //Since it will add a negative float
				if (this.intelligence < 0){
					this.intelligence = 0;
				}
			}
		}
	}
	
	/**
	Gets the intelligence of the enemy.
	@return The enemy's intelligence.
	*/
	public float getIntelligence(){
		return this.intelligence;
	}
	
	/**
	Override from parent class.
	Sets the health of the enemy when changing.
	Uses checkIfAlive to only change the health if the enemy is alive.
	Also increases or decreases the intelligence where applicable.
	@param healthChange the amount by which the health will
	increase or decrease.
	*/
	@Override
	public void setHealth(float healthChange){
		if (checkIfAlive()){
			if (healthChange > 0){
				this.intelligence += 1;
				this.health += healthChange;
				if (this.health > MAX_HEALTH){
					this.health = this.MAX_HEALTH;
				}
			}else if(healthChange < 0){
				this.intelligence -= 1;
				if (this.health <= 0){
					this.isAlive = false;
				}
			}		
		}
	}
	
	
	/**
	Creates a string of the class attributes.
	@return The string of the class attributes.
	*/
	@Override
	public String toString(){
		String s = "";
		
		s += "Name = ";
		s += getName();
		s += "\nHealth = ";
		s += Float.toString(getHealth());
		s += "\nIntelligence = ";
		s += Float.toString(getIntelligence());

		return s;
	}
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	