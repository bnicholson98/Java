public class TestBookstore{
	public static void main(String [] args){
		
		/* Test that a bookstore object can be created */
		Bookstore store = new Bookstore();
		/* Test that 0 is returned as initial size */
		store.getNumOfBooks();
		/* Test that a new book can be added */
		store.addBook("Stephen King","HHR");
		store.addBook("Ernest Cline","SCF");
		/* test remove function */
		store.removeBook("STPHNKHHR00001");
		/* test add existing */
		store.addExistingBook("STPHNKHHR00001");
		/* see if list is correct by testing the print function */
		// store.getListOfBooks();
		/* Test valid ID method using both and invalid and valid id */
		boolean invalidID = store.checkIfValid("hgfhTHU01");
		boolean validID = store.checkIfValid("ABCDEFNFI12345");
		System.out.println(invalidID);
		System.out.println(validID);
		/* Test for the getBooksInGenre by testing with an existing and non-existing genre in the store */
		store.addExistingBook("ABCDEFHRR000003");
		System.out.println(store.getBooksInGenre("HRR"));
		System.out.println(store.getBooksInGenre("ART"));
		/* Series of if statements to see if the checkForBook method works */
		if (store.checkForBook("AAABBBCCC12345")){
			System.out.println("Error, this is not expected");
		}else{
			if (store.checkForBook("ABCDEFHRR00003")){
				System.out.println("This is the correct result.");
			}else{
				System.out.println("Error, this is not expected");
			}
		}
		
	
	
	}
}