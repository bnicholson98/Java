/** Import of the ArrayList class */
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
/** import the Collections class */
import java.util.Collections;

/**
The Bookstore class
*/
public class Bookstore{
	/** Capacity of book store set as a constant */
	private static final int MAX_NUM_OF_BOOKS = 100000;
	/** fixed list of possible genres that the books can be under 3 lettered codes */
	private static final List<String> genres = Arrays.asList("HRR","SCF","CRI","NFI","ART");

	
	/** ArrayList to store the ID's of the books */
	private ArrayList<String> bookList= new ArrayList<String>();
	/** integer value for the id of the next added ID */
	private int nextIDNum = 00001;
	
	/** ID variable declared for usage within the class methods */
	private String ID;
	/** size variable used to store the size of the array at any given moment */
	private int storeSize;
	
	/**
	get the number of books in the store
	@return storeSize size of the bookstores list
	*/
	public int getNumOfBooks(){
		this.storeSize = this.bookList.size();
		return this.storeSize;
	}
	
	/**
	gets a list of books in a given genre by creating a new list
	and adding the ids with matching genres
	@param genre given the genre to search for
	@return genreList the list of ids of this genre within the bookstore
	*/
	public ArrayList<String> getBooksInGenre(String genre){
		ArrayList<String> genreList = new ArrayList<String>();
		/** evaluate if a valid genre is given */
		if (this.genres.contains(genre)){
			for (String id: this.bookList){
				if (genre == id.substring(6,9)){
					genreList.add(id);
				}
			}
		}
		else{
			return null;
		}
		return genreList;
	}
	
	/**
	prints the list of sorted book id's to the console
	*/
	public void getListOfBooks(){
		ArrayList<String> sortedList = new ArrayList<String>();
		sortedList = this.bookList;
		Collections.sort(sortedList);
		for (String id: sortedList){
			System.out.println(id);
		}
	}
	
	/** 
	returns if a given id is valid or not via a boolean value. Checks each of the
	three sections and if all suffice the needed requirements a value of true is returned
	@param ID takes the ID that will be evaluated as an arguement
	@return Boolean
	*/
	public boolean checkIfValid(String ID){
		if (ID.length() == 14){
			String section1 = ID.substring(0,6).toUpperCase();
			String section2 = ID.substring(6,9);
			String section3 = ID.substring(9);
			int intSection3;
			/** checks if any vowel is present in first section as it must be all consonants */
			if ((section1.indexOf('A') != -1) | (section1.indexOf('E') != -1) |(section1.indexOf('I') != -1) |(section1.indexOf('O') != -1) |(section1.indexOf('U') != -1)){
				return false;
			}
			/** checks if section two is a valid genre by comparing with the list of valid genres */
			if (!(this.genres.contains(section2))){
				return false;
			}
			/** attempts to parse last section to an int value, an error indicates this is not a valid int value */
			try{
				intSection3 = Integer.parseInt(section3);
			}catch (NumberFormatException ex){
				return false;
			}
			return true;
		}else{
			return false;
		}
	}
	
	/** 
	Uses ArrayList method to check if inputted ID is present within 
	the book list
	@param ID takes the ID that is being checked
	@return Boolean boolean value appropriate for if the book is within the list
	*/
	public boolean checkForBook(String ID){
		if (this.bookList.contains(ID)){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	method that adds a generated id number to the bookList
	@param Author takes author and converts to id format
	@param Genre genre is checked if valid and then and end number is generated from the last id used
	*/
	public void addBook(String author, String genre){
		String section1 = author.toUpperCase();
		section1 = section1.replaceAll("[AEIOU ]","");
		String section2;
		String section3;
		if (section1.length()> 6){
			section1 = section1.substring(0,6);
		}
		while (section1.length()<6){
			section1 += 'X';
		}
		if (!(this.genres.contains(genre))){
			return;
		}else{
			section2 = genre;
		}
		/** checks that there is space for this book within the book store */
		if (this.nextIDNum < this.MAX_NUM_OF_BOOKS){
			section3 = Integer.toString(this.nextIDNum);
			this.nextIDNum += 1;
		}else{
			return;
		}
		String id = section1 + section2 + section3;
		this.bookList.add(id);
	}
	
	/**
	Method that compares the numerical components of the ids from the existing id
	with each id within the list and places this id in the correct position according
	to its ne=umerical value
	@param newID The already known full id which will be added to the bookList
	*/
	public void addExistingBook(String newID){
		int numPart1;
		int numPart2 = Integer.parseInt(newID.substring(9));
		int idPos;
		/** inserted makes sure the existing id is only odded to
		the list once and also to test if it needs to be added at
		the end */
		boolean inserted = false;
		if (!(this.bookList.contains(newID))){
			for (String ID: this.bookList){
				numPart1 = Integer.parseInt(ID.substring(9));
				if (numPart2 < numPart1 & !(inserted)){
					idPos = bookList.indexOf(ID);
					this.bookList.add(idPos, newID);
					inserted = true;
				}
			}
		}
		if (!(inserted)){
			this.bookList.add(newID);
		}
	}
	
	/**
	Simply removes the required id from the bookList arrayList
	@param ID the ID that will removed from the store
	*/
	public void removeBook(String ID){
		this.bookList.remove(ID);
	}

	
	
}	
