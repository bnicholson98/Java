import java.util.Scanner;

public class Exercise1{
	public static void main(String [] args){
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Please enter a positive integer.");
		int num = scanner.nextInt();
		
		if (num < 1) {
			System.out.println("Number was not a positive integer!");
		}
		else {
			if (num%2 == 0){
				System.out.println("The number entered is even.");
			}
			else{
				System.out.println("The number entered is odd.");
			}
		}
	}
}