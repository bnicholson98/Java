import java.util.Scanner;
import java.util.ArrayList;

public class Exercise5{
	public static void main(String [] args){
		Scanner scanner = new Scanner(System.in);
		
		int num = 0;
		ArrayList<Integer> numList = new ArrayList<Integer>();
		
		while (num != -1){
			System.out.println("Enter a number.");
			num = scanner.nextInt();
			if (num != -1){
				numList.add(num);
			}
		}
		
		int lowest = numList.get(0);
		for (int i = 0; i < numList.size();i++){
			if (numList.get(i)<lowest){
				lowest = numList.get(i);
			}
		}
		System.out.println("Lowest: "+lowest);
		
		int highest = numList.get(0);
		for (int i = 0; i < numList.size();i++){
			if (numList.get(i)>highest){
				highest = numList.get(i);
			}
		}
		System.out.println("Highest: "+highest);
		
		int numOfValues = numList.size();
		System.out.println("Number of values: "+numOfValues);
		
		int sum = 0;
		for (int i = 0;i<numList.size();i++){
			sum += numList.get(i);
		}
		System.out.println("Sum of numbers: "+sum);
		
		
		float mean = (float) sum / numOfValues;
		System.out.println("Mean: "+mean);
	}
}