import java.util.Scanner;

public class Exercise3{
	public static void main(String [] args){
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Please enter two words.");
		String input = scanner.nextLine();
		int spacePos = input.indexOf(' ');
	    String word1 = input.substring(0,spacePos);
		String word2 = input.substring(spacePos+1);
		
		if (word1.length() == word2.length()){
			System.out.println("These words are anagrams of eachother.");
		}
		else{
			System.out.println("These words are not anagrams of eachother.");
		}
	}
}
		