import java.util.Scanner;

public class Exercise6{
	public static void main(String [] args){
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Please enter your password: ");
		String pass = scanner.nextLine();
		
		boolean finished = false;
		
		while (!finished){
			if (pass.length()<8){
				System.out.println("Password must be at least 8 characters long");
				finished = true;
			}
			
			if (!finished){
				int upperCase = 0;
				for (int i = 0;i<pass.length();i++){
					if (Character.isUpperCase(pass.codePointAt(i))){
						upperCase =1;
					}
				}
				if (upperCase == 0){
					System.out.println("Password needs an uppercase");
					finished = true;
				}
			}
			
			if (!finished){
				int digit = 0;
				for (int i = 0;i<pass.length();i++){
					if (Character.isDigit(pass.codePointAt(i))){
						digit =1;
					}
				}
				if (digit == 0){
					System.out.println("Password needs a digit");
					finished = true;
				}
			}
			if (!finished){
				for (int i = 0;i<pass.length();i++){
					if (pass.charAt(i) == ' '){					
						System.out.println("Password cannot contain a space");
						finished = true;
					}
				}
			}
			if (!finished){
				System.out.println("Password has been accepted!");
				finished = true;
			}
		}
	}
}
			
			