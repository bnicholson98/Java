import java.util.Scanner;

public class Exercise2{
	public static void main(String [] args){
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Please enter your full name.");
		String name = scanner.nextLine();
		int start = 0;
		
		for (int i = 0;i<name.length();i++){
			if (name.charAt(i) == ' '){
				String word = name.substring(start,i);
				System.out.println(word);
				start = i+1;
			}
		}
		String word = name.substring(start);
		System.out.println(word);
	}
}