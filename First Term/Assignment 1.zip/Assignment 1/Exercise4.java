import java.util.Scanner;

public class Exercise4{
	public static void main(String [] args){
		Scanner scanner = new Scanner(System.in);

		System.out.println("Please enter a mathematical expression.");
		String input = scanner.nextLine();
		
		int space1Pos = 0;
		int space2Pos = 0;
		
		int count = 0;
		for (int i=0;i<input.length();i++){
			if (input.charAt(i)==' '){
					if (count == 0){
						space1Pos = i;
						count++;
					}
					else {
						space2Pos = i;
					}
			}
		}
	
		
		String a = input.substring(0,space1Pos);
		char b = input.charAt(space1Pos+1);
		String c = input.substring(space2Pos+1);
		
		int operand1 = Integer.parseInt(a);
		char operation = b;
		int operand2 = Integer.parseInt(c);			
		
		int answer = 0;
		if (operation == '+'){
			answer = operand1 + operand2;
		}
		else if (operation == '-'){
			answer = operand1 - operand2;
		}
		else if (operation == '*'){
			answer = operand1 * operand2;
		}
		else if (operation == '/'){
			if (operand2 == 0){
				System.out.println("Cannot divide number by 0.");
			}
			else{
				answer = operand1 / operand2;
			}
		}
		else if (operation == '%'){
			answer = operand1 % operand2;
		}
		System.out.println(answer);
	}
}