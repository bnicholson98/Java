import java.util.Scanner;
import java.util.ArrayList;

public class Exercise3{
	public static void main(String [] args){
		Scanner scanner = new Scanner(System.in);
		
		//here i create the 2d integer array and set to the preset grid
		int[][] grid = new int[][]{
			{0, 1, 4, 5},
			{3, 7, 9, 7},
			{1, 8, 2, 1}
		};

		//nested for loops used to output the grid to the console using
		//varied prints to assure each line is correct
		for (int i = 0;i<3;i++){
			for (int j = 0;j<4;j++){
				System.out.print(grid[i][j]);
			}
			System.out.println();			
		}
		
		//declaration of variables which will be used within the main while block
		String input = scanner.nextLine();
		char xChar;
		char yChar;
		int x;
		int y;
		
		//while block that loops until a string equal to 'quit' is entered
		while (!(input.equals("quit"))){
			
			//xChar and yChar are set to the assigned coords entered
			//and then parsed to there integer equivelent
			xChar = input.charAt(0);
			yChar = input.charAt(1);
			x = Character.getNumericValue(xChar)-1;
			y = Character.getNumericValue(yChar)-1;
			System.out.println();
			
			//coordinate entered is located and printed
			System.out.println(grid[x][y]);
			
			//coordinate entered is set to 0
			grid[x][y] = 0;
			
			for (int i = 0;i<3;i++){
				for (int j = 0;j<4;j++){
					System.out.print(grid[i][j]);
				}
				System.out.println();			
			}
			System.out.println();
			input = scanner.nextLine();
		}
	}
}