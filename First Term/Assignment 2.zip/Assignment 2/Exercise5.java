import java.util.Scanner;
import java.util.ArrayList;

public class Exercise5{
	public static void main(String [] args){
		Scanner scanner = new Scanner(System.in);
		
		//Inputs strings and creats string list of numbers without spaces
		String string1 = scanner.nextLine();
		String string2 = scanner.nextLine();
		String[] s1 = string1.split(" ");
		String[] s2 = string2.split(" ");
		
		//creates a variable to store the length of the stringed list
		int s1Length = 1;
		int s2Length = 1;
		
		//the following finds the length of the two string lists by counting the spaces
		for( int i=0; i<string1.length(); i++ ) {
			if( string1.charAt(i) == ' ' ) {
				s1Length++;
			} 
		}
		for( int i=0; i<string2.length(); i++ ) {
			if( string2.charAt(i) == ' ' ) {
				s2Length++;
			} 
		}
		
		//Creates the ArrayLists for the two inputed lists
		int[] list1 = new int[s1Length];
		int[] list2 = new int[s2Length];
		
		//this parses the stringed list into the integer list as valid int elements
		for(int i = 0 ; i< s1Length; i++)
             list1[i] = (Integer.parseInt(s1[i]));
		for(int i = 0 ; i< s2Length; i++)
             list2[i] = (Integer.parseInt(s2[i]));
		 
		 
		//this adds the two lists to one joined list
		int[] finalList = new int[s1Length + s2Length];
		for (int i = 0;i < s1Length;i++){
			finalList[i] = list1[i];
		}
		for (int j = 0;j < s2Length;j++){
			finalList[s1Length + j] = list2[j];
		}
		
		//the following shows a bubble sort on this finalList
		int n = finalList.length;
        int temp = 0;  
        for(int i=0; i < n; i++){  
                for(int j=1; j < (n-i); j++){  
                          if(finalList[j-1] > finalList[j]){  
                                  
                                temp = finalList[j-1];  
                                finalList[j-1] = finalList[j];  
                                finalList[j] = temp;  
                        }  
                          
                }  
        }
		//Print statements to output this array in order
		System.out.println("The following is the two lists in ascending order:");
		for (int j = 0;j<n;j++){
					System.out.print(finalList[j] + " ");
				}
	}
}