import java.util.Scanner;
import java.util.ArrayList;

public class Exercise2{
	public static void main(String [] args){
		Scanner scanner = new Scanner(System.in);
		
		//declares list to store the strings entered
		ArrayList<String> wordList = new ArrayList<String>();
		
		//declares input variable to store the string inputed
		String input = scanner.nextLine();
		
		//loops by adding the inputted string to the list until a string
		//equal to 'quit' is entered
		while (!(input.equals("quit"))){
			wordList.add(input);
			input = scanner.nextLine();
		}
		
		//the following shows a bubble sort used to sort the strings in order of length
		//swapped is used as the condition variable to see if the list is still being changed
		boolean swapped = true;
		
		while (swapped == true){
			swapped = false;
			for (int i = 1;i < wordList.size();i++){
				if (wordList.get(i-1).length() > wordList.get(i).length()){
					String temp = wordList.get(i);
					wordList.set( i, wordList.get(i-1));
					wordList.set( i-1, temp);
					swapped = true;
				}
				
			}
		}
		//loop forward through list to output in ascending order
		System.out.println();
		System.out.println("Words in ascending order:");
		for (int i = 0;i < wordList.size();i++){
			System.out.println(wordList.get(i));
		}
		//loops backwards through the list to output in descending order
		System.out.println();
		System.out.println("Words in descending order:");
		for (int i = wordList.size()-1;i > -1;i--){
			System.out.println(wordList.get(i));
		}
		
		//print statement to announce the longest word and use .length to print this length
		System.out.println("Longest word is "+wordList.get(wordList.size()-1)+" of length "+wordList.get(wordList.size()-1).length());
	}
}