import java.util.Scanner;
import java.util.ArrayList;

public class Exercise4{
	public static void main(String [] args){
		Scanner scanner = new Scanner(System.in);
		
		//declaration of variables including the validInput which is the boolean
		//case for the main while block. And through input variables for the 3 lines
		//of the tic tac toe board
		boolean validInput = false;
		char c;
		String line1 = scanner.nextLine();
		String line2 = scanner.nextLine();
		String line3 = scanner.nextLine();
		
		//main while block to loop until a valid board is entered
		while (!(validInput)){
			validInput = true;
			
			//first if statement is used to validate that each board is the correct size
			if (line1.length()==3 && line2.length()==3 && line3.length() == 3){
				
				//a for and if block used on each line to validate each character
				//assuring it is only made up of either 'o' or 'x'
				for (int i = 0; i < line1.length(); i++){
					c = line1.charAt(i);  
					if ((c != 'o') && (c != 'x')){
						validInput = false;
					}
				}
				for (int i = 0; i < line2.length(); i++){
					c = line2.charAt(i);  
					if ((c != 'o') && (c != 'x')){
						validInput = false;
					}
				}
				for (int i = 0; i < line3.length(); i++){
					c = line3.charAt(i);  
					if ((c != 'o') && (c != 'x')){
						validInput = false;
					}
				}
			
			}else{
				validInput =false;
			}
			
			//if the board is still invalid then the user must reenter a board
			if (validInput == false){
				System.out.println("Please enter a valid board.");
				line1 = scanner.nextLine();
				line2 = scanner.nextLine();
				line3 = scanner.nextLine();
			}
		}
			
			
		//a char board array is created to hold each character in a 3x3 board
		char[][] board = new char[][]{
			{line1.charAt(0),line1.charAt(1),line1.charAt(2)},
			{line2.charAt(0),line2.charAt(1),line2.charAt(2)},
			{line3.charAt(0),line3.charAt(1),line3.charAt(2)}
		};
		
		System.out.println();
		
		//nested for loops to print out the board
		for (int i = 0;i<3;i++){
				for (int j = 0;j<3;j++){
					System.out.print(board[i][j]);
				}
				System.out.println();			
			}
		
		
		boolean winner = false; //this variable is used to see if the match is a draw
								//is remains false if a winner is not found
								
		//for each cell in the board, these nested for loops checks if all of a row
		//or all of a column is occupied by only a 'x' or 'o' and outputs the necessary statement
		for (int i = 0;i<3;i++){
			if ((board[i][0] == 'x') && (board[i][1] == 'x') && (board[i][2] == 'x')){
				System.out.println("x wins.");
				winner = true;
			}
			if ((board[i][0] == 'o') && (board[i][1] == 'o') && (board[i][2] == 'o')){
				System.out.println("o wins.");
				winner = true;
			}
		}
		for (int j = 0;j<3;j++){
			if ((board[0][j] == 'x') && (board[1][j] == 'x') && (board[2][j] == 'x')){
				System.out.println("x wins.");
				winner = true;
			}
			if ((board[0][j] == 'o') && (board[1][j] == 'o') && (board[2][j] == 'o')){
				System.out.println("o wins.");
				winner = true;
			}
		}
		
		
		//the next four if's test if left-to-right or right-to-left diagonal lines are occupied by
		//only an 'x' or 'o'
		if ((board[0][0] == 'x') && (board[1][1] == 'x') && (board[2][2] == 'x')){
			System.out.println("x wins.");
			winner = true;
		}
		if ((board[0][0] == 'o') && (board[1][1] == 'o') && (board[2][2] == 'o')){
			System.out.println("o wins.");
			winner = true;
		}
		if ((board[0][2] == 'x') && (board[1][1] == 'x') && (board[2][0] == 'x')){
			System.out.println("x wins.");
			winner = true;
		}
		if ((board[0][2] == 'o') && (board[1][1] == 'o') && (board[2][0] == 'o')){
			System.out.println("o wins.");
			winner = true;
		}
		//final if statement checks if the winner boolean is still false
		if (winner == false)
			System.out.println("Match is a draw."); //if so, a match draw is outputted
		
		
	}
}