import java.util.Scanner;
import java.util.ArrayList;

public class Exercise1{
	public static void main(String [] args){
		Scanner scanner = new Scanner(System.in);
		
		//Creates ArrayList to store the words that will be entered by the user
		ArrayList<String> wordsList = new ArrayList<String>();
		
		//declares the variable for the inputed strings
		String input = scanner.nextLine();
		
		//loops allowing the user to enter a string which is added to the arrayList
		//until a string equal to "quit" is entered
		while (!(input.equals("quit"))){
			if (input.equals("")){
				System.out.println("Please enter a string or 'quit' in order to end."); //validation if no string is entered
				input = scanner.nextLine();	
			}
			else{
				wordsList.add(input);
				input = scanner.nextLine();	
			}				
		}
		
		//Series of print statements and the initiation of length to print the
		//number of words inputed
		System.out.println();
		System.out.println("Number of words entered: ");
		int length = wordsList.size();
		System.out.println(length);
		
		//for loop used to loop through each element in the list and output it to the console
		System.out.println();
		System.out.println("Words entered:");
		for (int i = 0;i < length;i++){
			System.out.println(wordsList.get(i));
		}
	}
}