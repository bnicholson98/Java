
import java.io.PrintStream;
import java.util.concurrent.BlockingQueue;

// Continuously reads from message queue for a particular client,
// forwarding to the client.

public class ServerSender extends Thread {
  private BlockingQueue<Message> clientQueue;
  private PrintStream client;
  private MessageCommand messageList;

  /**
   * Constructs a new server sender.
   * @param q messages from this queue will be sent to the client
   * @param c the stream used to send data to the client
   */
  public ServerSender(BlockingQueue<Message> q, PrintStream c, MessageCommand m) {
    clientQueue = q;   
    client = c;
	messageList = m;
  }

  /**
   * Starts this server sender.
   */
  public void run() {
	int index = 0;
    try {
      while (true) {
		  
		Message msg = clientQueue.take(); // Matches EEEEE in ServerReceiver
		if (msg.getText().equals("current")){
			Message message = messageList.get(index-1);
			if (message != null){
				client.println(message);
			} else{
				client.println(msg.getText() + " does not exist");
			}
			continue;
		}
		if (msg.getText().equals("previous")){
			index = index - 1;
			Message message = messageList.get(index-1);
			if (message != null){
				client.println(message);
			} else{
				client.println(msg.getText() + " does not exist");
				index = index+1;
			}
			continue;
		}
		if (msg.getText().equals("next")){
			index = index + 1;
			Message message = messageList.get(index-1);
			if (message != null){
				client.println(message);
			} else{
				client.println(msg.getText() + " does not exist");
				index = index-1;
			}
			continue;
		}
		if (msg.getText().equals("delete")){
			messageList.delete(index-1);
			index = index-1;
			continue;
		}
		
        messageList.add(msg);
		index = messageList.getSize();
		client.println(msg); // Matches FFFFF in ClientReceiver
      }
    } catch (InterruptedException e) {
	  messageList.refresh();
      Report.behaviour("Server sender ending");
    }
  }
}

/*

 * Throws InterruptedException if interrupted while waiting

 * See https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/BlockingQueue.html#take--

 */
