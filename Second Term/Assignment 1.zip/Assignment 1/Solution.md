# Assignment 1 - Solution

---
Link to repository: https://git.cs.bham.ac.uk/bxn769/Assignment1

----
## Register and Login
I implemented a while(true) feature that loops unit a valid command (register, login, quit) has been entered. It sends the server the command and name, which then used this information from the client
and the ClientTable to see if the user is new or existing where necessary.
This while loop continues until a valid command and new or existing user (where applicable) is given.
---
If the above is not succesful, the server sends a fail message to the client which uses this to then report the user with an appropriate error message, allowing them to understand the mistake.
Otherwise, the user is added to the ClientTable and the threads are ran.
---
In my implementation, i decided to allow the user to immediately login after registering as i feel that this makes the most sense, as by registering, you are implying your desire to login.
I implemented this simply by allowing the threads to begin immediately after registration rather than enforcing another command prompt.
---
In my solution i did not allow multiple logins, i avoided this by creating a UserTable class. This is effectively an arrayList that stores the currently logged in users,
removing them once they have quit or logged out and adding them to the table when logging in.
---
To allow the use of users having messages saved and login details saved, i deleted the Remove method from the clientTable as well as the call of this method in the SenderReceiver class.

---
 
 Overall summary of Login and Register process:
 * Open socket
 * Login/reg request from client alongside username
 * Confirmation of success or failure of request from Server
 * Server starts accepting messages from this user
 * The user quitting closes the threads but does not remove the user from the table
 
 ---
 ## Logout and keep all messages
 
 I changed the Client class socket and command running to procede within a while loop, logout acts similiarly to quit but instead closes the threads (by breaking the loop of the ServerReceiver) but returns to the client class.
 
 The Server was changed to keep the blockingQueue for a user even after its socket has closed, this allows the messages to queue while the user is logged out,
 this queue of messages will be displayed to the user once logged in as the server can now send the messages.
 This is appropriate as it mirrors what any other  messaging system would do giving a user their unread messages at login.

---
## New message commands

I changed ClientSender to first receive a command variable from the client,
and sends this command to the server. If an unknown command is givin it will restart the while loop.
---
Send simply uses an if statement to check for the send command and then await the recipient and text, once this is achieved, the messenger acts as normal with the sending.
if the recipient is not logged in, the message is still added to their queue.

Once a previous/current/next command is sent to the ServerReceiver, it adds it to a message and puts on the clients message queue.
From here, the ServerSender utilises an index pointer and a new MessageCommand class (with uses arrays) to select the appropriate existing message and send it to the client.

Previous takes 1 off the pointer and next adds 1 to the pointer.
The MessageCommand getMessage method catches an out of bound exception and returns null to the sender, this handles the issue of selecting next when there are no more messages left.

delete is sent to the ServerSender in the same way as previous/next/current but uses the current pointer and remove method in the MessageCommand class to delete this message from the array.

---
# Changes

## Client
* arg length 1
* add socket opening and command procedures in while loop
* Try and while for logging in and registering commands
* Change to quit command to allow logout

## ClientSender
* allows commands of send/current/next etc. , send s to server
* Changes to quit command in this class

## UserTable
* new class
* Stores logged in user nicknames
* add method
* checkIfExist method
* remove method

## ClientTable
* Deleted remove method

## MessageCommand
* new Class
* stores array of clients saved messages
* add method
* get method
* getSize method
* delete mehthod
* refresh method (when new user logs in on same client)

## Server
* UserTable and MessageCommand created and passed through server to threads
* quit boolean for change in quit process
* receives new commands for loggin/registration adding to UserTable

## ServerReceiver
* Allows for new commands and handles in ways shown by code and explained above

## ServerSender
* Allows for new commands and handles in ways shown by code and explained above 










