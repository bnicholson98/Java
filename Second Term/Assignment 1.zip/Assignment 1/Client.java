// Usage:
//        java Client user-nickname server-hostname
//
// After initializing and opening appropriate sockets, we start two
// client threads, one to send messages, and another one to get
// messages.
//
// A limitation of our implementation is that there is no provision
// for a client to end after we start it. However, we implemented
// things so that pressing ctrl-c will cause the client to end
// gracefully without causing the server to fail.
//
// Another limitation is that there is no provision to terminate when
// the server dies.

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.concurrent.BlockingQueue;

class Client {

  public static void main(String[] args) {

    // Check correct usage:
    if (args.length != 1) {
      Report.errorAndGiveUp("Usage: java Client server-hostname");
    }

    // Initialize information:
    String hostname = args[0];
	while (true){
		// Open sockets:
		PrintStream toServer = null;
		BufferedReader fromServer = null;
		Socket server = null;

		try {
		  server = new Socket(hostname, Port.number); // Matches AAAAA in Server.java
		  toServer = new PrintStream(server.getOutputStream());
		  fromServer = new BufferedReader(new InputStreamReader(server.getInputStream()));
		} catch (UnknownHostException e) {
		  Report.errorAndGiveUp("Unknown host: " + hostname);
		} catch (IOException e) {
		  Report.errorAndGiveUp("The server doesn't seem to be running " + e.getMessage());
		}

		//Login or Register user process
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String command;
		String nickname = "";
		try{
			while(true){
				System.out.println("Command:");
				command = br.readLine();
				if (command.equals("register")){
					toServer.println(command);
					System.out.println("Please enter user-name to register: ");
					nickname = br.readLine();
					toServer.println(nickname);
					String response = fromServer.readLine();
					
					//Then loops or continues based on whether the server has returned a successful or failed attempt
					if (response.equals("fail")){
						System.out.println("User name already exists...");
					}else{
						System.out.println(nickname + " has been registered");
						break;
					}
				}
				else if(command.equals("login")){
					toServer.println(command);
					System.out.println("Please enter user-name to login");
					nickname = br.readLine();
					toServer.println(nickname);
					String response = fromServer.readLine();
					
					if (response.equals("fail")){
						System.out.println("User name does not exist...");
					}else if(response.equals("exists")){
						System.out.println(nickname + " is already logged in");
					}else{
						System.out.println(nickname + " has logged in");
						break;
					}
				}
				else if (command.equals("quit")){
					toServer.println("quit");
					System.exit(-1);
				} else {
					Report.errorAndGiveUp("Unknown command given");
				}
			}
		} catch (IOException e){
			Report.errorAndGiveUp("Problem running login or registration process" + e.getMessage());
		}
		

		// Create two client threads of a diferent nature:
		ClientSender sender = new ClientSender(nickname,toServer);
		ClientReceiver receiver = new ClientReceiver(fromServer);

		// Run them in parallel:
		sender.start();
		receiver.start();

		
		// Wait for them to end and close sockets.
		try {
		  sender.join();         // Waits for ClientSender.java to end. Matches GGGGG.
		  Report.behaviour("Client sender ended");
		  toServer.close();      // Will trigger SocketException
		  fromServer.close();    // (matches HHHHH in ClientServer.java).
		  server.close();        // https://docs.oracle.com/javase/7/docs/api/java/net/Socket.html#close()
		  receiver.join();
		  Report.behaviour("Client receiver ended");
		} catch (IOException e) {
		  Report.errorAndGiveUp("Something wrong " + e.getMessage());
		} catch (InterruptedException e) {
		  Report.errorAndGiveUp("Unexpected interruption " + e.getMessage());
		}
	
		Report.behaviour("Client ended. Goodbye.");
	}
  }
  
}

