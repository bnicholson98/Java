//List to store Strings of user names
//referred to when logging in or registering

import java.util.*;

public class UserTable{
	
	private ArrayList<String> nicknameList = new ArrayList<String>();
	
	//method to append name to nicknameList
	public void add(String nickname){
		nicknameList.add(nickname);
	}
	
	//method to return boolean depending on whether queried name exists in list
	public boolean checkIfExists(String nickname){
		if (nicknameList.contains(nickname)){
			return true;
		}else{
			return false;
		}
	}
	
	public void remove(String nickname){
		nicknameList.remove(nickname);
	}
}