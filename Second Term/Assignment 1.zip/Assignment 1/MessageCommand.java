import java.util.*;

public class MessageCommand{
	
	private ArrayList<Message> messageList = new ArrayList<Message>();
	
	public void add(Message message){
		messageList.add(message);
	}
	
	public Message get(int index){
		try{
			return messageList.get(index);
		}catch(IndexOutOfBoundsException e){
			return null;
		}
	}
	
	public int getSize(){
		return messageList.size();
	}
	
	public void delete(int index){
		messageList.remove(index);
	}
	
	public void refresh(){
		messageList = new ArrayList<Message>();
	}
	

}