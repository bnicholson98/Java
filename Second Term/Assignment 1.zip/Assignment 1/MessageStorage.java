import java.io.*;
import java.util.*;

public class MessageStorage{
	
	private Map<String, ArrayList<Message>> messageTable
		= new HashMap<>();
		
	public void addUser(String nickname){
		messageTable.put(nickname, new ArrayList<Message>());
	}
	
	public ArrayList<Message> getMessageArray(String nickname){
		return messageTable.get(nickname);
	}
	
	public void addMessage(String nickname, Message msg){
		ArrayList<Message> messageArray = messageTable.get(nickname);
		messageArray.add(msg);
		messageTable.put(nickname, messageArray);
	}

}	
		
