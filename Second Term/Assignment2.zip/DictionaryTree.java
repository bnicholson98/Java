import org.junit.jupiter.api.Assertions;

import java.util.*;
import java.util.function.BiFunction;

public class DictionaryTree {

    private Map<Character, DictionaryTree> children = new LinkedHashMap<>();
    private boolean isWord = false;
    private Optional<Integer> popularity = Optional.empty();
    
    /**
     * Inserts the given word into this dictionary.
     * If the word already exists, nothing will change.
     *
     * @param word the word to insert
     */
    void insert(String word) {
        if (word.length() == 0) {
            this.isWord = true;
        } else {
            if (!(children.containsKey(word.charAt(0)))) {
                children.put(word.charAt(0), new DictionaryTree());
            }
            children.get(word.charAt(0)).insert(word.substring(1));
        }
    }

    /**
     * Inserts the given word into this dictionary with the given popularity.
     * If the word already exists, the popularity will be overriden by the given value.
     *
     * @param word       the word to insert
     * @param popularity the popularity of the inserted word
     */
    void insert(String word, int popularity) {
        if (word.length() == 0) {
            this.isWord = true;
            this.popularity = Optional.of(popularity);
        } else {
            if (!(children.containsKey(word.charAt(0)))) {
                children.put(word.charAt(0), new DictionaryTree());
            }
            children.get(word.charAt(0)).insert(word.substring(1),popularity);
        }
    }

    /**
     * Removes the specified word from this dictionary.
     * Returns true if the caller can delete this node without losing
     * part of the dictionary, i.e. if this node has no children after
     * deleting the specified word.
     *
     * @param word the word to delete from this dictionary
     * @return whether or not the parent can delete this node from its children
     */
    boolean remove(String word) {
        Assertions.assertTrue(this.contains(word));

        if (word.length() == 0){
            this.isWord = false;
            return children.isEmpty();
        }
        else
            if ((children.get(word.charAt(0))).remove(word.substring(1))) {
                Character key = word.charAt(0);
                children.remove(key);
                return children.isEmpty();
            }

        return false;
    }

    /**
     * Determines whether or not the specified word is in this dictionary.
     *
     * @param word the word whose presence will be checked
     * @return true if the specified word is stored in this tree; false otherwise
     */
    boolean contains(String word) {
        if (word.length() == 0)
            return this.isWord;
        if (!(children.containsKey(word.charAt(0))))
            return false;
        else
            return children.get(word.charAt(0)).contains(word.substring(1));
    }

    /**
     * @param prefix the prefix of the word returned
     * @return a word that starts with the given prefix, or an empty optional
     * if no such word is found.
     */
    Optional<String> predict(String prefix) {
        throw new RuntimeException("DictionaryTree.predict not implemented yet");
    }


    /**
     * Predicts the (at most) n most popular full English words based on the specified prefix.
     * If no word with the specified prefix is found, an empty Optional is returned.
     *
     * @param prefix the prefix of the words found
     * @return the (at most) n most popular words with the specified prefix
     */
    List<String> predict(String prefix, int n) {
        throw new RuntimeException("DictionaryTree.predict not implemented yet");
    }

    /**
     * @return the number of leaves in this tree, i.e. the number of words which are
     * not prefixes of any other word.
     */
    int numLeaves() {
        int leaves = 0;
        if (children.isEmpty())
            return 1;
        for (Map.Entry<Character, DictionaryTree> child : children.entrySet())
            leaves += child.getValue().numLeaves();
        return leaves;
    }

    /**
     * @return the maximum number of children held by any node in this tree
     */
    int maximumBranching() {
        int maximum = children.size();

        for (Map.Entry<Character, DictionaryTree> child : children.entrySet())
            maximum = Math.max(maximum, child.getValue().maximumBranching());

        return maximum;

    }

    /**
     * @return the height of this tree, i.e. the length of the longest branch
     */
    int height() {
        int height = -1;

        for (Map.Entry<Character, DictionaryTree> child : children.entrySet())
            height = Math.max(height, child.getValue().height());

        return 1+height;

    }

    /**
     * @return the number of nodes in this tree
     */
    int size() {
        int size = 1;

        for (Map.Entry<Character, DictionaryTree> child : children.entrySet())
            size += child.getValue().size();

        return size;

    }

    /**
     * @return the longest word in this tree
     */
    String longestWord() {
        String word = longestWordFinder("");
        return word;
    }
    
    String longestWordFinder(String word){
        if (children.isEmpty())
            return word;
        Character key = 'a';
        int height = -1;
        for (Map.Entry<Character, DictionaryTree> child : children.entrySet()) {
            if (child.getValue().height() > height){
                height = child.getValue().height();
                key = child.getKey();
            }
        }
        word += key;
        return children.get(key).longestWordFinder(word);

    }

    /**
     * @return all words stored in this tree as a list
     */
    List<String> allWords() {
        List<String> allWords = new ArrayList<String>();
        wordsAdder(allWords, "");
        return allWords;

    }

    void wordsAdder(List<String> allWords, String word){
        if (this.isWord){
            allWords.add(word);
        }
        for (Map.Entry<Character, DictionaryTree> child : children.entrySet()) {
            String postfix = String.valueOf(child.getKey());
            child.getValue().wordsAdder(allWords, word+postfix);
        }
    }

    /**
     * Folds the tree using the given function. Each of this node's
     * children is folded with the same function, and these results
     * are stored in a collection, cResults, say, then the final
     * result is calculated using f.apply(this, cResults).
     *
     * @param f   the summarising function, which is passed the result of invoking the given function
     * @param <A> the type of the folded value
     * @return the result of folding the tree using f
     */
    <A> A fold(BiFunction<DictionaryTree, Collection<A>, A> f) {
        throw new RuntimeException("DictionaryTree.fold not implemented yet");
    }


}
