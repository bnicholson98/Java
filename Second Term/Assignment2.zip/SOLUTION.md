# Solution

---

link to git repo: https://git.cs.bham.ac.uk/bxn769/Assignment2

Also see DictionaryTreeTests.java for full in depth unit tests both proving 
code works and that Assertions have been used effectively.

## size

Initial size is 1 (as empty tree only holds the default node). The value of size is 
then added recursively by iterating through each child connected to each node
, adding 1 at each iteration.

---
## height

Starts at -1 (as the height of an empty tree is -1 by convention) and recursively follows
each path along the tree returning 1 + previous height when reaching a leaf. During the iteration of
of a nodes children, it uses Math.max to return the greater of the two values and in turn will overall only return the 
largest number and therefore the height.

---
## maximumBranching

Sets the branching to the size of the map (this equals the number of immediate child nodes this node has) 
and then recursively goes through each of this nodes children and returns the branching size of these nodes. 
Similarly to height, it uses Math.max to return the largest of two numbers and by doing this after each recursion, the final
value holding for maximum will be the most number of branches any one node has.

---
## longestWord

longestWord simply sets a string to the returned value of a helper method and then returns this value.
The helper method stores a word which increases by the adding the next key to the word until it gets to the end of the longest path.
The path it decides to take is done by iterating through each child node of the current node and then
going to the node with the largest height. This continues concatenating the node's keys into a string and then return this string back to the original longestWord method once a leaf is met.


---
## numLeaves

numLeaves recursively iterates through each children nodes of each node. Any time a node has no children
(i.e. is a leaf) it will return 1, which is added the leaves variable which is then returned once every node has been visitied.


---
## contains

contains utilises the isWord boolean flag held by any node. It uses the containsKey hashMap method
by using the first letter of the word as the key. If this key does not exist in the map, false is returned, else it will
continue to recurse through the tree by following the edges letter by letter. Once the algorithm has reach the last node of the word
it will return the value stored in isWord. 

---
## insert

Insert uses recursion to follow through the tree by each letter as the keys of the nodes, if
it reaches a letter which has not yet been added to the tree, it puts a key of the letter into the map and a new tree for its value and then 
continues the recursion by substringing the rest of the word and recaling the insert method with this new word.
Once it has reach the end of the word and the last node, it will set the isWord boolean to true.

---
## allWords

allWords initiates an arrayList and then uses a wordsAdder helper function to create the list of all words in the tree, which is then returned.
The helper method works by passing a word and recursively calling the function while giving it the word +
the character added from the last node. Once a node which has isWord set to true, it will add the current word in use (which will be created by adding
the letters of its path) to the words list. Once each node has been visited, the state of the words list will now contains all words which hold the isWord boolean to true, this list is then returned by the original allWords method.

---
## remove

Remove uses assertions to assert that the word being removed is contained within the tree.
It then recursively calles through the tree from the word by using the first letter of the word as the key, and the the rets of the substringed word as the arguement for the recursive call.
Once it reaches the end of the word it sets isWord to false and then returns true if it is a leaf. This return indicates whether it is safe to remove this node from the map. If it is a leaf, it's parent node will delete is from it's map and then return true if this node is now a leaf.
This recursion works by now checking if this node is a leaf and it's parent deleting it where necessary and continuing until
deleting a node will affect another word.

---
