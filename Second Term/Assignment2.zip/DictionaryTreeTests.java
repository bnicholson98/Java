import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import java.util.List;

/**
 * @author Kelsey McKenna
 */
public class DictionaryTreeTests {

    @Test
    public void heightOfRootShouldBeZero() {
        DictionaryTree unit = new DictionaryTree();
        Assertions.assertEquals(0, unit.height());
    }

    @Test
    public void heightOfWordShouldBeWordLength() {
        DictionaryTree unit = new DictionaryTree();
        unit.insert("word", 0);
        Assertions.assertEquals("word".length(), unit.height());
    }

    @Test
    public void containsTest(){
        DictionaryTree unit = new DictionaryTree();
        unit.insert("word");
        Assertions.assertTrue(unit.contains("word"));
        Assertions.assertFalse(unit.contains("hello"));
    }

    @Test
    public void numLeavesTest(){
        DictionaryTree unit = new DictionaryTree();
        unit.insert("word");
        unit.insert("hello");
        unit.insert("hi");
        unit.insert("high");
        Assertions.assertEquals(3, unit.numLeaves());
    }

    @Test
    public void originalMaxBranchEqualsZero(){
        DictionaryTree unit = new DictionaryTree();
        Assertions.assertEquals(0, unit.maximumBranching());
    }

    @Test
    public void insertAndRemove(){
        DictionaryTree unit = new DictionaryTree();
        unit.insert("word");
        Assertions.assertTrue(unit.contains("word"));
        unit.remove("word");
        Assertions.assertFalse(unit.contains("word"));
    }

    @Test
    public void removeNodesDuringRemove(){
        DictionaryTree unit = new DictionaryTree();
        unit.insert("word");
        unit.remove("word");
        Assertions.assertEquals(1, unit.size());
    }

    @Test
    public void longestWordTest(){
        DictionaryTree unit = new DictionaryTree();
        unit.insert("word");
        unit.insert("and");
        String longest = unit.longestWord();
        Assertions.assertEquals("word", longest);
    }

    @Test
    public void sizeEqualsLengthPlusOne(){
        DictionaryTree unit = new DictionaryTree();
        unit.insert("word");
        Assertions.assertEquals(5,unit.size());
    }

    @Test
    public void initialAllWordsIsEmpty(){
        DictionaryTree unit = new DictionaryTree();
        List<String> list = unit.allWords();
        Assertions.assertEquals(0, list.size());
    }

    @Test
    public void allWordsTest(){
        DictionaryTree unit = new DictionaryTree();
        unit.insert("word");
        unit.insert("hello");
        unit.insert("test");
        unit.insert("java");
        unit.insert("code");
        List<String> list = unit.allWords();
        Assertions.assertEquals(5,list.size());
    }

}
