import java.io.*;

/**
 * @author Kelsey McKenna
 */
public class CLI {

    /**
     * Loads words (lines) from the given file and inserts them into
     * a dictionary.
     *
     * @param f the file from which the words will be loaded
     * @return the dictionary with the words loaded from the given file
     * @throws IOException if there was a problem opening/reading from the file
     */
    static DictionaryTree loadWords(File f) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(f))) {
            String word;
            DictionaryTree d = new DictionaryTree();
            while ((word = reader.readLine()) != null) {
                d.insert(word);
            }

            return d;
        }
    }

    public static void main(String[] args) throws IOException {

        System.out.print("Loading dictionary ... ");
        DictionaryTree d = loadWords(new File(args[0]));
        System.out.println("done");
        int size = d.size();
        int height = d.height();
        int maxBranch = d.maximumBranching();
        int leaves = d.numLeaves();
        System.out.println("size = "+size);
        System.out.println("height = "+height);
        System.out.println("maxBranch = "+maxBranch);
        System.out.println("leaves = "+leaves);
        System.out.println(d.contains("sgjhbshjgb"));
        System.out.println(d.contains("hello"));
        d.remove("word");
        //System.out.println(d.allWords());
        System.out.println(d.longestWord());
        d.insert("word",1);
/*
        System.out.println("Enter prefixes for prediction below.");

        try (BufferedReader fromUser = new BufferedReader(new InputStreamReader(System.in))) {
            while (true) {
                System.out.println("---> " + d.predict(fromUser.readLine()));
            }
        }
*/
    }

}

